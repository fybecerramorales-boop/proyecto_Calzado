package Vista;

import Controlador.Logica;
import Controlador.Producto;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import javax.swing.ImageIcon;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

/**
 * Vista principal del almacén de calzado.
 * Tres pestañas: REGISTRO, CONSULTA y ACTUALIZA / ELIMINA.
 */
public class Pantalla2 extends JFrame {

    private static final String[] COLUMNAS = {
        "ID", "Marca", "Modelo", "Talla", "Color", "Categoría", "Unidades", "Precio unitario"
    };

    private final Logica logica = new Logica();
    private final NumberFormat formatoPesos = NumberFormat.getCurrencyInstance(Locale.of("es", "CO"));

    // Pestaña REGISTRO
    private JTextField marcaTxt, modeloTxt, tallaTxt, colorTxt, unidadesTxt, precioTxt;
    private JComboBox<String> categoriaCombo;

    // Pestaña CONSULTA
    private JTextField buscarTxt;
    private JTable tablaConsulta;
    private JLabel totalLbl;

    // Pestaña ACTUALIZA / ELIMINA
    private JTable tablaActualiza;
    private JTextField marcaActTxt, modeloActTxt, tallaActTxt, colorActTxt, unidadesActTxt, precioActTxt;
    private JComboBox<String> categoriaActCombo;

    public Pantalla2() {
        setTitle("Calzado Stephen - Almacén de calzado");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Ícono de la ventana (logo de Calzado Stephen)
        java.net.URL urlIcono = getClass().getResource("/Vista/recursos/icono.png");
        if (urlIcono != null) {
            setIconImage(new ImageIcon(urlIcono).getImage());
        }

        JTabbedPane pestanas = new JTabbedPane();
        pestanas.addTab("REGISTRO", crearPanelRegistro());
        pestanas.addTab("CONSULTA", crearPanelConsulta());
        pestanas.addTab("ACTUALIZA / ELIMINA", crearPanelActualiza());
        pestanas.addChangeListener(e -> {
            // Al entrar a una pestaña de tablas, se cargan los datos más recientes
            int i = pestanas.getSelectedIndex();
            if (i == 1) {
                cargarConsulta();
            } else if (i == 2) {
                cargarActualiza();
            }
        });

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(crearEncabezado(), BorderLayout.NORTH);
        getContentPane().add(pestanas, BorderLayout.CENTER);
        setSize(820, 650);
        setLocationRelativeTo(null);

        logica.crearTablaProducto();
    }

    // ───────────────────────── Encabezado con logo ──────────────────────
    private JPanel crearEncabezado() {
        JPanel encabezado = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 8));
        encabezado.setBackground(new Color(22, 36, 71));

        // Logo del almacén (se carga desde Vista/recursos/logo.png)
        java.net.URL urlLogo = getClass().getResource("/Vista/recursos/logo.png");
        if (urlLogo != null) {
            Image logo = new ImageIcon(urlLogo).getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
            encabezado.add(new JLabel(new ImageIcon(logo)));
        }

        JPanel textos = new JPanel(new GridBagLayout());
        textos.setOpaque(false);
        JLabel nombre = new JLabel("Calzado Stephen");
        nombre.setFont(new Font("SansSerif", Font.BOLD, 28));
        nombre.setForeground(Color.WHITE);
        JLabel subtitulo = new JLabel("Control de inventario del almacén");
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 14));
        subtitulo.setForeground(new Color(250, 228, 190));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.gridy = 0;
        textos.add(nombre, gbc);
        gbc.gridy = 1;
        textos.add(subtitulo, gbc);
        encabezado.add(textos);

        return encabezado;
    }

    // ───────────────────────── Pestaña REGISTRO ─────────────────────────
    private JPanel crearPanelRegistro() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        marcaTxt = new JTextField(20);
        modeloTxt = new JTextField(20);
        tallaTxt = new JTextField(20);
        colorTxt = new JTextField(20);
        unidadesTxt = new JTextField(20);
        precioTxt = new JTextField(20);
        categoriaCombo = new JComboBox<>(Logica.CATEGORIAS);

        agregarFila(panel, 0, "Marca", marcaTxt);
        agregarFila(panel, 1, "Modelo", modeloTxt);
        agregarFila(panel, 2, "Talla", tallaTxt);
        agregarFila(panel, 3, "Color", colorTxt);
        agregarFila(panel, 4, "Categoría", categoriaCombo);
        agregarFila(panel, 5, "Unidades", unidadesTxt);
        agregarFila(panel, 6, "Precio unitario (COP)", precioTxt);

        JButton guardar = new JButton("Guardar");
        guardar.addActionListener(e -> guardarProducto());
        JButton limpiar = new JButton("Limpiar");
        limpiar.addActionListener(e -> limpiarRegistro());

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        botones.add(guardar);
        botones.add(limpiar);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 5, 5, 5);
        panel.add(botones, gbc);

        return panel;
    }

    private void agregarFila(JPanel panel, int fila, String etiqueta, java.awt.Component campo) {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridy = fila;
        gbc.insets = new Insets(6, 5, 6, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        panel.add(new JLabel(etiqueta), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(campo, gbc);
    }

    private void guardarProducto() {
        try {
            Producto p = new Producto(
                    marcaTxt.getText().trim(),
                    modeloTxt.getText().trim(),
                    Integer.parseInt(tallaTxt.getText().trim()),
                    colorTxt.getText().trim(),
                    categoriaCombo.getSelectedItem().toString(),
                    Integer.parseInt(unidadesTxt.getText().trim()),
                    Double.parseDouble(precioTxt.getText().trim()));

            String error = logica.validar(p);
            if (error != null) {
                JOptionPane.showMessageDialog(this, error, "Datos incompletos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (logica.insertarNuevoProducto(p)) {
                JOptionPane.showMessageDialog(this, "El producto se guardó correctamente.",
                        "Registro guardado", JOptionPane.INFORMATION_MESSAGE);
                limpiarRegistro();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo guardar el producto.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Talla, unidades y precio deben ser numéricos.",
                    "Error en los datos", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarRegistro() {
        marcaTxt.setText("");
        modeloTxt.setText("");
        tallaTxt.setText("");
        colorTxt.setText("");
        unidadesTxt.setText("");
        precioTxt.setText("");
        categoriaCombo.setSelectedIndex(0);
        marcaTxt.requestFocus();
    }

    // ───────────────────────── Pestaña CONSULTA ─────────────────────────
    private JPanel crearPanelConsulta() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        buscarTxt = new JTextField(20);
        JButton buscar = new JButton("Buscar");
        buscar.addActionListener(e -> cargarConsulta());
        buscarTxt.addActionListener(e -> cargarConsulta());
        JButton verTodo = new JButton("Ver todo");
        verTodo.addActionListener(e -> {
            buscarTxt.setText("");
            cargarConsulta();
        });

        JPanel arriba = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        arriba.add(new JLabel("Buscar (marca, modelo, color o categoría):"));
        arriba.add(buscarTxt);
        arriba.add(buscar);
        arriba.add(verTodo);

        tablaConsulta = new JTable(modeloSoloLectura());
        totalLbl = new JLabel(" ");

        panel.add(arriba, BorderLayout.NORTH);
        panel.add(new JScrollPane(tablaConsulta), BorderLayout.CENTER);
        panel.add(totalLbl, BorderLayout.SOUTH);
        return panel;
    }

    private void cargarConsulta() {
        List<Producto> productos = logica.consultarProductos(buscarTxt.getText());
        tablaConsulta.setModel(llenarModelo(productos));

        int pares = 0;
        double valor = 0;
        for (Producto p : productos) {
            pares += p.unidades;
            valor += p.unidades * p.precio_unitario;
        }
        totalLbl.setText(productos.size() + " producto(s)  |  " + pares
                + " par(es) en inventario  |  Valor del inventario: " + formatoPesos.format(valor));
    }

    // ───────────────────── Pestaña ACTUALIZA / ELIMINA ──────────────────
    private JPanel crearPanelActualiza() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        tablaActualiza = new JTable(modeloSoloLectura());
        tablaActualiza.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        // Al seleccionar una fila, sus datos pasan a los campos editables
        tablaActualiza.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                cargarFilaSeleccionada();
            }
        });

        JPanel arriba = new JPanel(new BorderLayout(5, 5));
        arriba.add(new JLabel("Seleccione un producto de la tabla para actualizar o eliminar"), BorderLayout.NORTH);
        JScrollPane scroll = new JScrollPane(tablaActualiza);
        scroll.setPreferredSize(new java.awt.Dimension(700, 180));
        arriba.add(scroll, BorderLayout.CENTER);

        marcaActTxt = new JTextField(15);
        modeloActTxt = new JTextField(15);
        tallaActTxt = new JTextField(15);
        colorActTxt = new JTextField(15);
        unidadesActTxt = new JTextField(15);
        precioActTxt = new JTextField(15);
        categoriaActCombo = new JComboBox<>(Logica.CATEGORIAS);

        JPanel form = new JPanel(new GridBagLayout());
        agregarFila(form, 0, "Marca", marcaActTxt);
        agregarFila(form, 1, "Modelo", modeloActTxt);
        agregarFila(form, 2, "Talla", tallaActTxt);
        agregarFila(form, 3, "Color", colorActTxt);
        agregarFila(form, 4, "Categoría", categoriaActCombo);
        agregarFila(form, 5, "Unidades", unidadesActTxt);
        agregarFila(form, 6, "Precio unitario (COP)", precioActTxt);

        JButton actualizar = new JButton("Actualizar");
        actualizar.addActionListener(e -> actualizarProducto());
        JButton eliminar = new JButton("Eliminar");
        eliminar.addActionListener(e -> eliminarProducto());
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        botones.add(actualizar);
        botones.add(eliminar);

        panel.add(arriba, BorderLayout.NORTH);
        panel.add(form, BorderLayout.CENTER);
        panel.add(botones, BorderLayout.SOUTH);
        return panel;
    }

    private void cargarActualiza() {
        tablaActualiza.setModel(llenarModelo(logica.consultarProductos(null)));
        limpiarCamposActualiza();
    }

    private void cargarFilaSeleccionada() {
        int fila = tablaActualiza.getSelectedRow();
        if (fila < 0) {
            return;
        }
        marcaActTxt.setText(String.valueOf(tablaActualiza.getValueAt(fila, 1)));
        modeloActTxt.setText(String.valueOf(tablaActualiza.getValueAt(fila, 2)));
        tallaActTxt.setText(String.valueOf(tablaActualiza.getValueAt(fila, 3)));
        colorActTxt.setText(String.valueOf(tablaActualiza.getValueAt(fila, 4)));
        categoriaActCombo.setSelectedItem(String.valueOf(tablaActualiza.getValueAt(fila, 5)));
        unidadesActTxt.setText(String.valueOf(tablaActualiza.getValueAt(fila, 6)));
        // El precio se guarda sin formato en la columna 7 (Double)
        precioActTxt.setText(String.valueOf(tablaActualiza.getValueAt(fila, 7)));
    }

    private void actualizarProducto() {
        int fila = tablaActualiza.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Primero seleccione un producto de la tabla.",
                    "Ningún producto seleccionado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            Producto p = new Producto(
                    marcaActTxt.getText().trim(),
                    modeloActTxt.getText().trim(),
                    Integer.parseInt(tallaActTxt.getText().trim()),
                    colorActTxt.getText().trim(),
                    categoriaActCombo.getSelectedItem().toString(),
                    Integer.parseInt(unidadesActTxt.getText().trim()),
                    Double.parseDouble(precioActTxt.getText().trim()));
            p.id_producto = Integer.parseInt(String.valueOf(tablaActualiza.getValueAt(fila, 0)));

            String error = logica.validar(p);
            if (error != null) {
                JOptionPane.showMessageDialog(this, error, "Datos incompletos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int confirmacion = JOptionPane.showConfirmDialog(this,
                    "¿Guardar los cambios de \"" + p.marca + " " + p.modelo + "\"?",
                    "Confirmar actualización", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (confirmacion != JOptionPane.YES_OPTION) {
                return;
            }

            if (logica.actualizarProducto(p)) {
                JOptionPane.showMessageDialog(this, "El producto se actualizó correctamente.",
                        "Registro actualizado", JOptionPane.INFORMATION_MESSAGE);
                cargarActualiza();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo actualizar el producto.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Talla, unidades y precio deben ser numéricos.",
                    "Error en los datos", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarProducto() {
        int fila = tablaActualiza.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Primero seleccione un producto de la tabla.",
                    "Ningún producto seleccionado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = Integer.parseInt(String.valueOf(tablaActualiza.getValueAt(fila, 0)));
        String nombre = tablaActualiza.getValueAt(fila, 1) + " " + tablaActualiza.getValueAt(fila, 2);

        int confirmacion = JOptionPane.showConfirmDialog(this,
                "¿Eliminar \"" + nombre + "\"? Esta acción no se puede deshacer.",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        if (logica.eliminarProducto(id)) {
            JOptionPane.showMessageDialog(this, "El producto se eliminó correctamente.",
                    "Registro eliminado", JOptionPane.INFORMATION_MESSAGE);
            cargarActualiza();
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo eliminar el producto.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarCamposActualiza() {
        marcaActTxt.setText("");
        modeloActTxt.setText("");
        tallaActTxt.setText("");
        colorActTxt.setText("");
        unidadesActTxt.setText("");
        precioActTxt.setText("");
        categoriaActCombo.setSelectedIndex(0);
    }

    // ───────────────────────── Utilidades de tabla ──────────────────────
    private DefaultTableModel modeloSoloLectura() {
        return new DefaultTableModel(COLUMNAS, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    private DefaultTableModel llenarModelo(List<Producto> productos) {
        DefaultTableModel modelo = modeloSoloLectura();
        for (Producto p : productos) {
            modelo.addRow(new Object[]{
                p.id_producto, p.marca, p.modelo, p.talla, p.color,
                p.categoria, p.unidades, p.precio_unitario
            });
        }
        return modelo;
    }
}
