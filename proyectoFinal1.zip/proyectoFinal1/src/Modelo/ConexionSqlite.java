package Modelo;

import Controlador.Producto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Capa de acceso a datos (Modelo) del almacén de calzado, con SQLite y JDBC.
 * Requisito: sqlite-jdbc-3.36.x.jar agregado a las librerías del proyecto.
 */
public class ConexionSqlite {

    // Archivo de base de datos (se crea automáticamente si no existe)
    private static final String NOMBRE_ARCHIVO_BD = "almacen-calzado.db";

    // Ruta de la base de datos: si existe en el directorio de trabajo se usa esa;
    // si no, se ubica junto al .jar o a las clases que se están ejecutando.
    private static final String URL = "jdbc:sqlite:" + resolverRutaBaseDatos();

    private static String resolverRutaBaseDatos() {
        java.io.File enDirectorioActual = new java.io.File(NOMBRE_ARCHIVO_BD);
        if (enDirectorioActual.exists()) {
            return enDirectorioActual.getAbsolutePath();
        }
        try {
            java.io.File origen = new java.io.File(
                    ConexionSqlite.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            java.io.File carpeta = origen.isFile() ? origen.getParentFile() : origen;
            return new java.io.File(carpeta, NOMBRE_ARCHIVO_BD).getAbsolutePath();
        } catch (Exception e) {
            return NOMBRE_ARCHIVO_BD;
        }
    }

    // ─── Obtener conexión ─────────────────────────────────────────
    public static Connection conectar() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(URL);
        } catch (SQLException e) {
            System.out.println("❌ Error al conectar: " + e.getMessage());
        }
        return conn;
    }

    // ─── Crear la tabla de productos ──────────────────────────────
    public static void crearTablaProducto() {
        String sql = "CREATE TABLE IF NOT EXISTS productos ("
                   + "id_producto    INTEGER PRIMARY KEY AUTOINCREMENT, "
                   + "marca          TEXT    NOT NULL, "
                   + "modelo         TEXT    NOT NULL, "
                   + "talla          INTEGER NOT NULL, "
                   + "color          TEXT    NOT NULL, "
                   + "categoria      TEXT    NOT NULL, "
                   + "unidades       INTEGER NOT NULL, "
                   + "precio_unitario REAL   NOT NULL"
                   + ");";

        try (Connection conn = conectar();
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println("❌ Error al crear tabla: " + e.getMessage());
        }
    }

    // ─── Insertar un producto ─────────────────────────────────────
    // Devuelve true si se guardó. Usa PreparedStatement (evita errores con
    // apóstrofes e inyección SQL).
    public static boolean insertarProducto(Producto p) {
        String sql = "INSERT INTO productos (marca, modelo, talla, color, categoria, unidades, precio_unitario) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?);";

        try (Connection conn = conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.marca);
            ps.setString(2, p.modelo);
            ps.setInt(3, p.talla);
            ps.setString(4, p.color);
            ps.setString(5, p.categoria);
            ps.setInt(6, p.unidades);
            ps.setDouble(7, p.precio_unitario);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("❌ Error al insertar: " + e.getMessage());
            return false;
        }
    }

    // ─── Actualizar un producto existente ─────────────────────────
    public static boolean actualizarProducto(Producto p) {
        String sql = "UPDATE productos SET marca = ?, modelo = ?, talla = ?, color = ?, "
                   + "categoria = ?, unidades = ?, precio_unitario = ? WHERE id_producto = ?;";

        try (Connection conn = conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.marca);
            ps.setString(2, p.modelo);
            ps.setInt(3, p.talla);
            ps.setString(4, p.color);
            ps.setString(5, p.categoria);
            ps.setInt(6, p.unidades);
            ps.setDouble(7, p.precio_unitario);
            ps.setInt(8, p.id_producto);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error al actualizar producto: " + e.getMessage());
            return false;
        }
    }

    // ─── Eliminar un producto ─────────────────────────────────────
    public static boolean eliminarProducto(int id_producto) {
        String sql = "DELETE FROM productos WHERE id_producto = ?;";

        try (Connection conn = conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id_producto);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error al eliminar producto: " + e.getMessage());
            return false;
        }
    }

    // ─── Consultar productos (para llenar las JTable) ─────────────
    // Si 'filtro' no está vacío, busca por marca, modelo, color o categoría.
    public static List<Producto> consultarProductos(String filtro) {
        List<Producto> lista = new ArrayList<>();
        boolean hayFiltro = filtro != null && !filtro.trim().isEmpty();
        String sql = "SELECT id_producto, marca, modelo, talla, color, categoria, unidades, precio_unitario "
                   + "FROM productos"
                   + (hayFiltro ? " WHERE marca LIKE ? OR modelo LIKE ? OR color LIKE ? OR categoria LIKE ?" : "")
                   + " ORDER BY id_producto;";

        try (Connection conn = conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            if (hayFiltro) {
                String patron = "%" + filtro.trim() + "%";
                for (int i = 1; i <= 4; i++) {
                    ps.setString(i, patron);
                }
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Producto p = new Producto();
                    p.id_producto     = rs.getInt("id_producto");
                    p.marca           = rs.getString("marca");
                    p.modelo          = rs.getString("modelo");
                    p.talla           = rs.getInt("talla");
                    p.color           = rs.getString("color");
                    p.categoria       = rs.getString("categoria");
                    p.unidades        = rs.getInt("unidades");
                    p.precio_unitario = rs.getDouble("precio_unitario");
                    lista.add(p);
                }
            }
        } catch (SQLException e) {
            System.out.println("❌ Error al consultar productos: " + e.getMessage());
        }
        return lista;
    }
}
