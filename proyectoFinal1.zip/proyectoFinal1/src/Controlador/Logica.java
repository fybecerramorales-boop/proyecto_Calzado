package Controlador;

import Modelo.ConexionSqlite;
import java.util.List;

/**
 * Controlador: puente entre la Vista (pantallas) y el Modelo (base de datos).
 * Aquí también se validan las reglas del negocio antes de guardar.
 */
public class Logica {

    public static final String[] CATEGORIAS = {
        "Deportivo", "Formal", "Casual", "Sandalia", "Bota", "Escolar"
    };

    // Crea la tabla si todavía no existe
    public void crearTablaProducto() {
        ConexionSqlite.crearTablaProducto();
    }

    /**
     * Valida un producto. Devuelve un mensaje de error, o null si todo está bien.
     */
    public String validar(Producto p) {
        if (p.marca == null || p.marca.trim().isEmpty()) {
            return "La marca es obligatoria.";
        }
        if (p.modelo == null || p.modelo.trim().isEmpty()) {
            return "El modelo es obligatorio.";
        }
        if (p.color == null || p.color.trim().isEmpty()) {
            return "El color es obligatorio.";
        }
        if (p.talla < 15 || p.talla > 50) {
            return "La talla debe estar entre 15 y 50.";
        }
        if (p.unidades < 0) {
            return "Las unidades no pueden ser negativas.";
        }
        if (p.precio_unitario <= 0) {
            return "El precio debe ser mayor que cero.";
        }
        return null;
    }

    public boolean insertarNuevoProducto(Producto p) {
        crearTablaProducto();
        return ConexionSqlite.insertarProducto(p);
    }

    public boolean actualizarProducto(Producto p) {
        crearTablaProducto();
        return ConexionSqlite.actualizarProducto(p);
    }

    public boolean eliminarProducto(int id_producto) {
        crearTablaProducto();
        return ConexionSqlite.eliminarProducto(id_producto);
    }

    public List<Producto> consultarProductos(String filtro) {
        crearTablaProducto();
        return ConexionSqlite.consultarProductos(filtro);
    }
}
