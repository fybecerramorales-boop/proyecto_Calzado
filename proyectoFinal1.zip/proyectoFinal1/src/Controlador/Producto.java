package Controlador;

/**
 * Clase de datos: representa un par de calzado del almacén.
 */
public class Producto {

    // Atributos
    public int id_producto;
    public String marca;
    public String modelo;
    public int talla;
    public String color;
    public String categoria;
    public int unidades;
    public double precio_unitario;

    // Constructores
    public Producto() {
    }

    public Producto(String marca, String modelo, int talla, String color,
                    String categoria, int unidades, double precio_unitario) {
        this.marca = marca;
        this.modelo = modelo;
        this.talla = talla;
        this.color = color;
        this.categoria = categoria;
        this.unidades = unidades;
        this.precio_unitario = precio_unitario;
    }

    // Métodos
    public void info() {
        System.out.println("Producto:");
        System.out.println("marca: " + marca);
        System.out.println("modelo: " + modelo);
        System.out.println("talla: " + talla);
        System.out.println("color: " + color);
        System.out.println("categoria: " + categoria);
        System.out.println("unidades: " + unidades);
        System.out.println("precio unitario: " + precio_unitario);
    }

    public static void main(String[] args) {
        Producto p1 = new Producto("Nike", "Air Max", 40, "Negro", "Deportivo", 10, 350000);
        p1.info();
        System.out.println();
        Producto p2 = new Producto("Vélez", "Oxford clásico", 42, "Café", "Formal", 5, 280000);
        p2.info();
    }
}
